import Header from "./components/Header";
import MainContent from "./components/MainContent";
import Footer from "./components/Footer";

function App() {
  const title = "Welcome to React Components";
  const message = "This is passed from Parent to Child using Props.";

  return (
    <div>
      <Header title={title} />
      <MainContent message={message} />
      <Footer />
    </div>
  );
}

export default App;