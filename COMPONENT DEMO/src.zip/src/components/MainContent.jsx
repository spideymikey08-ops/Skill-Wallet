function MainContent(props) {
  return (
    <div>
      <p>{props.message}</p>
    </div>
  );
}

export default MainContent;